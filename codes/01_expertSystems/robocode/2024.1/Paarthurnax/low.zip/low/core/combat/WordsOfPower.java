package low.core.combat;

import java.awt.geom.*;
import robocode.*;
import low.core.utility.*;

// Classe responsável pelo gerenciamento do GuessFactor utilizado no Battle Royale
public class WordsOfPower {
	private Point2D startPoint, lastPoint;
	private double startgunheading, direction, bulletspeed, bulletd, escapeAngle;
	private long lasttime;
	private int[] segment, indexes;
	public int weight;
	
	public WordsOfPower(PaarthurnaxPrey e, long time, int[] segment, int[] indexes){
		Point2D myLocation = PaarthurnaxWings.getMyLocation();
		startPoint = new Point2D.Double(myLocation.getX(), myLocation.getY());
		lastPoint = new Point2D.Double(e.getX(), e.getY());
		startgunheading = PaarthurnaxWings.angle(lastPoint, startPoint);
		direction = e.getLateralDirection();
		bulletspeed = PaarthurnaxWings.getBulletVelocity(PaarthurnaxWings.getPower(e));
		escapeAngle = Math.asin(8/bulletspeed);
		bulletd = -bulletspeed;
		lasttime = time;
		this.segment = segment;
		weight = 1;
		this.indexes = indexes;
	}
	
	// Construtor alternativo para mirar em si
	public WordsOfPower(AdvancedRobot target, PaarthurnaxPrey from, int[] segment, long time, double latdirection, double power, int[] indexes){
		startPoint = new Point2D.Double(from.getX(), from.getY());
		if (from.lastMyLocation == null)
			lastPoint = new Point2D.Double(target.getX(), target.getY());
		else
			lastPoint = from.lastMyLocation;
		startgunheading = PaarthurnaxWings.angle(lastPoint, startPoint);
		direction = latdirection;
		bulletspeed = PaarthurnaxWings.getBulletVelocity(power);
		escapeAngle = Math.asin(8/bulletspeed);
		bulletd = -bulletspeed;
		lasttime = time;
		this.segment = segment;
		weight = 0;
		this.indexes = indexes;
	}
	
	public boolean updateEnemy(PaarthurnaxPrey enemy, long time){
		// Interpolação linear de onde os alvos estavam para caso não aconteça uma atualização frequente,
		// necessário no battle royale para manter ajustado o ângulo relativo do disparo 
		double ang = PaarthurnaxWings.angle(enemy, lastPoint);
		double dist = enemy.distance(lastPoint)/(time-lasttime);
		while (lasttime < time){
			if (startPoint.distance(lastPoint) <= bulletd){
				double gf = getGF();
				segment[Math.min(segment.length-1, Math.max(0, (int)Math.round((1+gf)*(segment.length-1)/2)))] += Math.max(1, weight);
				return true; // Retorna verdade se a onda gerada por nossa bala atingiu e deve ser removida
			}
			lasttime++;
			bulletd += bulletspeed;
			lastPoint = PaarthurnaxWings.projectPoint(lastPoint, ang, dist);
		}
		return false;
	}
	
	public double getGF(){
		return robocode.util.Utils.normalRelativeAngle(PaarthurnaxWings.angle(lastPoint, startPoint)-startgunheading)*direction/escapeAngle;
	}
}
