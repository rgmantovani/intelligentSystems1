package low.core.utility;

import java.util.*;
import java.awt.geom.*;
import robocode.*;
import low.core.utility.*;

// Classe Utilitária, detém métodos vitais para o funcionamento das demais classes 
public class PaarthurnaxWings {
    private static Point2D myLocation;
    private static AdvancedRobot robot;
    private static PaarthurnaxPrey currentTarget;
    private static HashMap enemies;
	private static double fieldWidth, fieldHeight;
	private static HashMap stats;
	private static HashMap selfstats;
	public static final int GFS = 31;
	public static final int CRIB_LENGTH = 3;

	public static final int[] segmentSizes = {2, 3, 3, 3, 4, 10};

	public static final int[] meleeSegmentSizes = {2, 3, 3, 8, 10};

	/*
		Segmentos melee (Battle Royale):
			2 Parede
			3 Aceleração
			3 Direção Lateral
			8 antigravity
			10 tempo de voo da bala
	*/

	public static final int[] selfSegmentSizes = {2, 3, 3, 4, 10};

	/*
		Segmentos próprios:
		2 Parede
		3 Aceleração
		3 Velocidade Lateral
		4 Tempo
		10 tempo de voo da bala
	*/

    public static void iniciaRound(AdvancedRobot r){ 
		robot = r;
		fieldWidth = robot.getBattleFieldWidth();
		fieldHeight = robot.getBattleFieldHeight();
		if (stats == null){
			stats = new HashMap();
			selfstats = new HashMap();
		}
        enemies = new HashMap();
		currentTarget = null;
		myLocation = new Point2D.Double();
		update();
	}

    public static void reiniciaRound(){ 
		enemies.clear();
	}

    public static PaarthurnaxPrey getCurrentTarget(){ 
		return currentTarget;
	} 

    public static void setCurrentTarget(PaarthurnaxPrey e){ 
		currentTarget = e;
	}

    public static Point2D projectPoint(Point2D startPoint, double theta, double dist){
		return new Point2D.Double(startPoint.getX() + dist * Math.sin(theta), startPoint.getY() + dist * Math.cos(theta));
	}

    public static Point2D getMyLocation(){ 
		return myLocation;
	}

	public static AdvancedRobot getRobot(){ 
		return robot;
	}

    public static PaarthurnaxPrey getEnemy(String name){ 
		if (!enemies.containsKey(name))
			enemies.put(name, new PaarthurnaxPrey());
		return (PaarthurnaxPrey)enemies.get(name);
	}

	public static Iterator getEnemies(){ 
		return enemies.values().iterator();
	}

    public static double normalize(double angle){
		return robocode.util.Utils.normalRelativeAngle(angle);
	}

	public static double absNormalize(double angle){
		return robocode.util.Utils.normalAbsoluteAngle(angle);
	}

	public static boolean inFieldTrunc(Point2D p){
		return new Rectangle2D.Double(30, 30, fieldWidth-60, fieldHeight-60).contains(p);
	}

	public static boolean inField(Point2D p){
		return new Rectangle2D.Double(17.9, 17.9, fieldWidth-35.8, fieldHeight-35.8).contains(p);
	}

	public static double angle(Point2D point2, Point2D point1){
		return Math.atan2(point2.getX()-point1.getX(), point2.getY()-point1.getY());
	}

    public static void update(){
		myLocation.setLocation(robot.getX(), robot.getY());
	}

    public static double getTargetRating(PaarthurnaxPrey e){
		return e.distance(myLocation) - e.energy;
	}

    public static double getPower(PaarthurnaxPrey target){
		double power = Math.min(robot.getEnergy()/5, 3);
		if (target.energy < 16) {
			double powerToFinish = Math.min(target.energy/4, (target.energy+2)/6);
			if (target.distance(myLocation) < 300){
				double targetEnergy = target.energy + target.lastBulletPower*3*Math.min(1, (1.5-target.distance(myLocation)/200));
				powerToFinish = Math.min(targetEnergy/4, (targetEnergy+2)/6);
			}
			power = Math.min(power, powerToFinish);
		} 
        power = Math.min(power, 1200/target.distance(myLocation));
		return power;
	}

	public static double getBulletVelocity(double power){
		return 20-3*power;
	}
	
    public static void robotDeath(String name){
		if (enemies.containsKey(name)){
			if (enemies.remove(name) == currentTarget){
                currentTarget = null;
            }
        }
	}

	public static PaarthurnaxWill getStats(String name){
		name = getRealName(name);
		if (stats.containsKey(name))
			return (PaarthurnaxWill)stats.get(name);
		else {
			Object ret;
			stats.put(name, ret = new PaarthurnaxWill(segmentSizes, meleeSegmentSizes, GFS));
			return (PaarthurnaxWill)ret;
		}
	}

	public static PaarthurnaxWill getSelfStats(String name){
		if (selfstats.containsKey(name))
			return (PaarthurnaxWill)selfstats.get(name);
		else {
			PaarthurnaxWill ret;
			selfstats.put(name, ret = new PaarthurnaxWill(selfSegmentSizes, selfSegmentSizes, GFS));
			return ret;
		}
	}

	public static String getRealName(String name){
		if (name.indexOf('(') >= 0)
			name = name.substring(0, name.indexOf('(')).trim();
		return name;
	}

	
}