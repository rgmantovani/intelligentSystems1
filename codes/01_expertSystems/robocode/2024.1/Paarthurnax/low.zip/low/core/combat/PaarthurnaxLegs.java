package low.core.combat;

import java.util.*;
import java.awt.geom.*;
import robocode.*;
import low.core.utility.*;

// Classe responsável pela movimentação em Battle Royale
public class PaarthurnaxLegs {
    private static Point2D next, last;
	
	public static void init(){
		next = null;
		last = null;
	}
	
	public static void minimumRiskMovement(AdvancedRobot r){
		Point2D myLocation = PaarthurnaxWings.getMyLocation();
		PaarthurnaxPrey currentTarget = PaarthurnaxWings.getCurrentTarget();
		if (currentTarget != null){
			if (last == null)
				last = new Point2D.Double(myLocation.getX(), myLocation.getY());
			if (next == null)
				next = last;
			boolean changed = false;
			double distance = Math.min(300, myLocation.distance(currentTarget)/2);
			for (double angle = 0; angle < Math.PI*2; angle += .1){
				Point2D p = PaarthurnaxWings.projectPoint(myLocation, angle, distance);
				if (PaarthurnaxWings.inFieldTrunc(p) && findRisk(p, r) < findRisk(next, r)){
					changed = true;
					next = p;
				}
			}
			if (changed)
				last = myLocation;
			distance = next.distance(myLocation);
			double turn = PaarthurnaxWings.angle(next, myLocation)-r.getHeadingRadians();
			if (Math.cos(turn) < 0){
				turn += Math.PI;
				distance = -distance;
			}
			r.setTurnRightRadians(PaarthurnaxWings.normalize(turn));

			// Evita acertar a parede quando realizando a esquiva
			if (!PaarthurnaxWings.inField(PaarthurnaxWings.projectPoint(myLocation, r.getHeadingRadians(), Math.max(-20, Math.min(20, distance)))))
				distance = 0;
			r.setAhead((Math.abs(r.getTurnRemainingRadians()) > 1) ? 0 : distance);
		}
	}
	
	// Método utilizado para buscar riscos
	public static double findRisk(Point2D point, AdvancedRobot robot){
		Point2D myLocation = PaarthurnaxWings.getMyLocation();
		double risk = 4/last.distanceSq(point) + .1/myLocation.distanceSq(point);
		Iterator it = PaarthurnaxWings.getEnemies();
		while (it.hasNext()){
			PaarthurnaxPrey e = (PaarthurnaxPrey)it.next();

			double thisrisk = Math.max(robot.getEnergy(), e.energy)/point.distanceSq(e);

			thisrisk *= 1+targetingMeOdds(point, e)* (Math.abs(Math.cos(PaarthurnaxWings.angle(myLocation, point) - PaarthurnaxWings.angle(e, myLocation))));
			thisrisk += targetingMeOdds(point, e)/(5+robot.getOthers());
			
			// Condição voltada a não colidir com inimigos
			if (new Line2D.Double(myLocation, point).intersects(new Rectangle2D.Double(e.getX()-36, e.getY()-36, 72, 72))) // Se dois quadrados de 36 por 36 forem colidir enquanto se movendo
				thisrisk *= 4;																							   // por um vetor, então uma linha representando o vetor vai cruzar
																														   // um quadrado de 72 por 72 centralizado no mesmo espaço
			risk += thisrisk;																							   // evitando a colisão dos quadrados (representando os robôs)
		}
		return risk;
	}
	
	// Método que verifica se o Paarthurnax é o inimigo mais próximo de algum inimigo seu, caso for, a chance se ser alvo dele é maior
	public static double targetingMeOdds(Point2D myLocation, PaarthurnaxPrey enemy){
		int closer = 0;
		for (Iterator it = PaarthurnaxWings.getEnemies(); it.hasNext();){
			PaarthurnaxPrey e2 = (PaarthurnaxPrey)it.next();
			if (enemy != e2 && enemy.distance(e2)*.9 < enemy.distance(myLocation))
				closer++;
		}
		if (closer <= 0 || PaarthurnaxWings.getRobot().getTime()-enemy.lastHitTime < 200)
			return 1;
		else
			return 0;
	}
	
	// Método que retorna a "força" com a qual a anti-gravidade do inimigo em questão está te repelindo
	// Utilizado para calcular os segmentos melee (battle royale) na classe PaarthurnarPrey
	public static double rawAntigravityAtPoint(Point2D location, PaarthurnaxPrey currentEnemy){
		if (!PaarthurnaxWings.inField(location))
			return Double.POSITIVE_INFINITY;
		double total = (1+Math.abs(Math.cos(PaarthurnaxWings.angle(currentEnemy, location) - PaarthurnaxWings.angle(PaarthurnaxWings.getMyLocation(), currentEnemy))))/location.distanceSq(PaarthurnaxWings.getMyLocation());
		for (Iterator it = PaarthurnaxWings.getEnemies(); it.hasNext();){
			PaarthurnaxPrey next = (PaarthurnaxPrey)it.next();
			if (next != currentEnemy)
				total += (1+Math.abs(Math.cos(PaarthurnaxWings.angle(currentEnemy, location) - PaarthurnaxWings.angle(next, currentEnemy))))/location.distanceSq(next);
		}
		return total;
	} // A movimentação anti-gravidade utiliza a distância e os angulos nos eixos x e y do inimigo para calcular a força com que a anti-gravidade do inimigo está te atraindo ou repelindo,
	  // desta forma, é possível sempre buscar se mover para a região de menos resistência (que repele menos), assim, evitando ao máximo a aproximação de qualquer inimigo em campo.
}