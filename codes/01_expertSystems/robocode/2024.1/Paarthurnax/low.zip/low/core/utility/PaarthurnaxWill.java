package low.core.utility;

import java.util.*;
import java.awt.geom.*;
import robocode.*;
import low.core.utility.*;
import java.util.zip.*;
import java.io.*;

// Classe responsável pelo gerenciamento dos status (segmentos)
public class PaarthurnaxWill implements Serializable {
	private Object stats;
	protected int gfs;
	
	public PaarthurnaxWill(int[] segments, int[] meleesegments, int gfs){
		this.gfs = gfs;
		Object[] tempstats = new Object[2];
		tempstats[0] = init(segments, 0);
		tempstats[1] = init(meleesegments, 0);
		stats = tempstats;
	}
	
	private Object init(int[] segments, int index){
		if (index == segments.length){
			return new int[gfs];
		} else {
			Object[] ret = new Object[segments[index]];
			for (int i=0; i<segments[index]; i++)
				ret[i] = init(segments, index+1);
			return ret;
		}
	}
	
	public int[] getSegment(int[] indexes){
		return getSegment(stats, indexes, 0);
	}
	
	protected int[] getSegment(Object stats, int[] indexes, int ind){
		if (ind == indexes.length)
			return (int[])stats;
		else {
			Object[] array = (Object[])stats;
			return getSegment(array[indexes[ind]], indexes, ind+1);
		}
	}
}