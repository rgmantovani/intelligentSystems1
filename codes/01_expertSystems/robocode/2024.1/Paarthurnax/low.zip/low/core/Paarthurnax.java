package low.core;

/*
Autores:
Gabriel Candelária Wiltgen Barbosa
Camila Costa Durante
*/

import robocode.*;
import java.util.*;
import java.awt.geom.*;
import java.util.ArrayList;
import java.awt.Color;
import low.core.utility.*;
import low.core.combat.*;

/*
“What is better: to be born good or to overcome your evil nature through great effort?”
― Paarthurnax
*/

public class Paarthurnax extends AdvancedRobot {
	// Variáveis que seram utilizadas
	public static final int BINS = 151;
	public static final int CENTER_BIN = (BINS - 1)/2;
	public static final int DIST_SEGS = 5;
	public static final int LAT_VEL_SEGS = 4;
	public static final double MAX_DIST = 1000;
	public static final int GUN_BINS = 230; 
    public static final int MAX_MATCHES = 50;  
	public static final char ROUND_BREAK = ((char)(((-127)<<8)|(0xFF&((byte)(-127)))));
	public static double[] noSegSurfStats = new double[BINS];
	public static double[][][] surfStats = new double[DIST_SEGS][LAT_VEL_SEGS][BINS];
	public static Point2D.Double mLocal;  // Localização do Paarthurnax
    public static Point2D.Double iLocal;  // Localização do inimigo
	public static ArrayList ondasIni = new ArrayList();
	public static ArrayList ondaPassada = new ArrayList();
	public static OndaInimiga surfWave;
    public static double eneInimigo = 100.0; // Variável que será utilizada para atualizar o gasto de enrgia do inimigo
	public static Rectangle2D.Double limiteMapa; // Variável que será utilizada para gerar um retângulo que representará o mapa para calculos
    public static Point2D.Double inimigoAlvo;
    public static boolean trocandoDirecao;
    public int direcaoAnterior;

	static StringBuilder data = new StringBuilder(); // String Dinâmica que será utilizada para calcular a angulação do disparo 

    public void run() {
		
		// Limpa a String Dinâmica data
		try{
            data.delete(60000, 80000);
        } catch(Exception e) {}
			
        // Aplicação das cores
		setBodyColor(new Color(230, 230, 227)); 
	    setGunColor(new Color(230, 230, 227));
	    setRadarColor(new Color(230, 230, 210)); 
	    setBulletColor(new Color(186, 214, 255)); 
	    setScanColor(new Color(33, 32, 31));

		// Configurações de arma e radar
        setAdjustGunForRobotTurn(true);
        setAdjustRadarForGunTurn(true);

		// Definindo o limite do mapa com retângulo gerado
		limiteMapa = new java.awt.geom.Rectangle2D.Double(17.9, 17.9, getBattleFieldWidth() - 35.8, getBattleFieldHeight() - 35.8);
        inimigoAlvo = new Point2D.Double(getBattleFieldWidth() / 2,
				getBattleFieldHeight() / 2);

        // Inicializa os utilitários
        PaarthurnaxWings.iniciaRound(this);
		PaarthurnaxLegs.init();

		// Insere ROUND_BREAK na String Dinâmica
		data.insert(0,ROUND_BREAK);

		// Inicialização e atualização constante de componentes essenciais
        do {
            PaarthurnaxWings.update(); // Mantem os valores de PaarthurnaxWings atualizados
            PaarthurnaxPrey target = PaarthurnaxWings.getCurrentTarget(); // Define o alvo atual
            PaarthurnaxEyes.ativaRadar(this, target); // Liga o Radar
			if(getOthers() > 1){
				PaarthurnaxLegs.minimumRiskMovement(this);
			} // Inicializa a movimentação de Battle Royale (Minimum Risk)
			execute();
        } while (true); 
    }

	public void onScannedRobot(ScannedRobotEvent e) { // Método de evento quando um alvo é escaneado
		
		// Inicializa a classe de controle de alvo (PaarthurnaxPrey)
		PaarthurnaxPrey scannedRobot;
		scannedRobot = PaarthurnaxWings.getEnemy(e.getName());
		scannedRobot.update(this, e);

		// Define o alvo atual, que será utilizado dentro da classe (PaarthurnaxPrey)
		if (PaarthurnaxWings.getCurrentTarget() == null || (PaarthurnaxWings.getTargetRating(scannedRobot) < PaarthurnaxWings.getTargetRating(PaarthurnaxWings.getCurrentTarget()) && getGunHeat()/getGunCoolingRate() > 4)){
			PaarthurnaxWings.setCurrentTarget(scannedRobot);
		}

        // x x x        
		// Esquiva 1 v 1 (Wave Surfing) --------------------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------------------
		
		mLocal = new Point2D.Double(getX(), getY()); // Definindo a localização do Paarthurnax
		OndaInimiga oi = new OndaInimiga(); // Inicializa as ondas (balas disparadas)
		double absRumo = e.getBearingRadians(); // Salva o rumo absoluto do inimigo
			
		double velLateral = (getVelocity()*Math.sin(absRumo)); // Salva a velocidade lateral do inimigo

		// Controle do radar
		setTurnRadarRightRadians(PaarthurnaxWings.normalize((absRumo += getHeadingRadians()) - getRadarHeadingRadians()) * 2);

		// Atribuições da onda gerada
		oi.direcaoOnda = (int)Math.signum(velLateral + 0.000000000000001);
		oi.angDireto = absRumo + Math.PI;

		double eDistance;
		oi.bins = surfStats[(int)((eDistance = e.getDistance())*(DIST_SEGS/MAX_DIST))] [(int)((Math.abs(velLateral) + 1))/3]; 
        ondaPassada.add(0,oi); // Adiciona a onda ao arraylist de ondas passadas (ondaPassada)
        addWave(eneInimigo - (eneInimigo = e.getEnergy())); // Adiciona a onda gerada pela perda de energia do inimigo as ondas geradas pelos inimigos (ondasIni)
		iLocal = project(mLocal, absRumo, eDistance); // Atualização da localização do inimigo após a detecção de uma onda inimiga

		// Atualiza as ondas, verificando se a próxima ainda é esquivável, caso contrário a remove de ondasIni
		atualizaOndas();

		// Condição para realizar esse tipo de esquiva apenas quando for 1 v 1
		if(getOthers() == 1){
			// Define a direção que deverá ser realizado o movimento de esquiva
			int direction = 1;
        	if (prevendoFuturo(-1) < prevendoFuturo(1)) 
            	direction = -1;
			
			// Utilização de parede suavizada para definir o angulo de esquiva, evita a colisão com a parede durante uma esquiva 
			double goAngle = paredeSuavizada(mLocal, rumoAbs(iLocal, mLocal) + direction*offsetEsquiva(mLocal.distance(iLocal)), direction) - 
				getHeadingRadians();
			
			// Realização do movimento de esquiva utilizando o angulo anteriormente gerado pela parede suavizada
			setAhead(Math.cos(goAngle)*Double.POSITIVE_INFINITY);
         	setTurnRightRadians(Math.tan(goAngle));
		}


        // ^ Esquiva 1 v 1 (Wave Surfing) ^ ----------------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------------------




        // x x x
        // GuessFactor -> Targeting System for BattleRoyale ------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------------------

		int[] indexes = scannedRobot.getSegmentIndexes(); // Inicializa e recebe os index do inimigo atual
		int[] segment = PaarthurnaxWings.getStats(e.getName()).getSegment(indexes); // Inicializa e recebe os status do inimigo atual
		if (getEnergy() > 0){
			scannedRobot.updateWaves(segment, e.getTime(), indexes);
		} // Atualiza os status do inimigo escaneado sempre que sua energia for maior que 0

		// Condição para realizar esse tipo de disparo apenas quando for battle royale
		if (scannedRobot == PaarthurnaxWings.getCurrentTarget() && getOthers() > 1){
			// Inicialização de variáveis
			int bestindex = segment.length/2; 
			double absBearing = getHeadingRadians()+e.getBearingRadians();
			double power = PaarthurnaxWings.getPower(scannedRobot);

			// Ângulo previsto 1, baseado na velociade do tiro inimigo e sua direção lateral
			double gf1 = Math.asin(8/PaarthurnaxWings.getBulletVelocity(power)) * scannedRobot.getLateralDirection(); 

			// Condição para energia do inimigo maior que 0 (para atualizar constantemente)
			if (scannedRobot.energy > 0)
				for (int i=0; i<31; i++)
				{
					double tempBearing = absBearing + gf1*(2.0*i/(segment.length-1)-1); // Angulação de possível rumo inimigo

					// Condição para ignorar casos onde a bala atingiria o inimigo fora do mapa, evitando perda de energia atoa
					if (PaarthurnaxWings.inField(PaarthurnaxWings.projectPoint(PaarthurnaxWings.getMyLocation(), tempBearing, e.getDistance()*(PaarthurnaxWings.getBulletVelocity(power)/(PaarthurnaxWings.getBulletVelocity(power)+8)))) && segment[i] > segment[bestindex])
						bestindex = i; // Salva os melhores casos
				}
			double offset = gf1*(2.0*bestindex/(segment.length-1)-1); // Offset do ângulo que será utilizado, baseado nos melhores casos de acerto

			// Aponta o canhão para o inimigo, utilizando o offset e a direção absoluta do inimigo
			setTurnGunRightRadians(PaarthurnaxWings.normalize(absBearing+offset-getGunHeadingRadians()));

			// Atira se estiver dentro de um valor  
			if (Math.abs(getGunTurnRemaining()) < 5){
				setFireBullet(power);
			}

			// Condição para os robôs desabilitados
			if(scannedRobot.energy < 0.1){
				// Aponta a arma direto para a posição do inimigo, uma vez que ele não pode se mover
				setTurnGunRightRadians(PaarthurnaxWings.normalize(absBearing - getGunHeadingRadians()));
			}
		} 

        // ^ GuessFactor -> Targeting System for BattleRoyale ^ --------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------------------




		// x x x
        // GuessFactor -> Targeting System for 1 v 1 -------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------------------

		// Converte as componentes de velocidade do inimigo em um formato compacto de 16 bits, 
		// onde os 8 bits mais significativos representam a componente seno da velocidade e os 
		// 8 bits menos significativos representam a componente cosseno e os insere na string Dinâmica data
        data.insert(0,(char)(((int)Math.round(e.getVelocity()*Math.sin(velLateral = e.getHeadingRadians()- absRumo))<<8)|
        	(0XFF&((byte)(e.getVelocity()*Math.cos(velLateral)))))); 
        
		// Define o poder de disparo e o ângulo que será utilizado para disparar
        double bulletPower = getBullePower1v1(eDistance, eneInimigo); 
		double bulletAngle = getGunAngle(Math.min(66,Math.min(data.length(), ondaPassada.size())), eDistance, bulletPower); 

		// Condição para realizar esse tipo de disparo apenas quando for 1 v 1 
		if(scannedRobot == PaarthurnaxWings.getCurrentTarget() && getOthers() == 1){
			setTurnGunRightRadians(PaarthurnaxWings.normalize(absRumo + bulletAngle - getGunHeadingRadians()));
			// Condição para continuar atirando enquanto o inimigo está atirando
			// O lastShotFactor retorna sempre menor que 1 quando o inimigo está atirando dentro do padrão (de 15 em 15 turnos), ou seja,
			// caso retorne um valor maior que 1 significa que ele levou mais turnos que o esperado para atirar, sendo assim, não está atirando 
			if(e.getEnergy() >= scannedRobot.lastBulletPower && scannedRobot.lastShotFactor < 1){ 
				setFire(bulletPower);
			}	
		}

		// ^ GuessFactor -> Targeting System for 1 v 1 ^ ---------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------------------




		// x x x
        // Sobrevivência (estratégia Anti-Ram) -------------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------------------

		// Condição que verifica se existe um inimigo, se é apenas 1 e se ainda possui energia para disparar
		if(e.getEnergy() > scannedRobot.lastBulletPower && getOthers() == 1 && scannedRobot != null){ 
			// Caso a Distância do inimigo seja menor que 100 se afasta do inimigo
			if(e.getDistance() < 100){ 
				// Parede suavizada para o afastamento contornar a borda do mapa
				double angAfastamento = paredeSuavizada(mLocal, (-(e.getBearingRadians())), 1);  
				virarFrenteTras(this, angAfastamento); // Função para garantir que o Paarthurnax se afastará
			}
		} 
		
        // ^ Sobrevivência (estratégia Anti-Ram) ^ ---------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------------------




        // x x x
        // Inimigo sem energia (FINISH HIM) ----------------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------------------

		// Condição para executar o Ram apenas se em 1 v 1
        if(getOthers() == 1){
			// Inicializa uma variável onda inimiga para salvar a próxima onda esquivável
			OndaInimiga temBalaVindo = getPossEsquiva();
            if(e.getEnergy() < 1){
				// Condição que verifica se ainda existem ondas esquiváveis (balas vindo)
				if(temBalaVindo == null){
					double tempDistInimigo = e.getDistance();
					double tempRumoInimigo = e.getBearingRadians();
					int tempDirecao = sign(angRelativoInimigo(getRadarHeadingRadians()));
					inimigoAlvo.x = getX() + tempDistInimigo
						* Math.sin(getHeadingRadians() + tempRumoInimigo);
					inimigoAlvo.y = getY() + tempDistInimigo
						* Math.cos(getHeadingRadians() + tempRumoInimigo);
					// Vai em direcao ao inimigo para executá-lo com Ram 
					do {
						double angle = angRelativoInimigo(getHeadingRadians());
						tempDirecao = 1;
						if (Math.abs(angle) > Math.PI / 2) {
							angle += (tempDirecao = -1) * Math.PI * sign(angle);
						}
						direcaoAnterior = tempDirecao;
						setTurnRightRadians(PaarthurnaxWings.normalize(angle));
						setAhead(Double.MAX_VALUE * tempDirecao);
						setTurnGunRightRadians(Double.POSITIVE_INFINITY); // Gira o canhão para a direita (só de sacanagem)
						setTurnRadarRightRadians(Double.POSITIVE_INFINITY); // Gira o radar para direita (só de sacanagem)
						scan();
					} while (e.getEnergy() < 1.9); // Condição do while apenas por cautela (1.9 por ser um padrão de disparo forte)
				}        
            }
        }

        // ^ Inimigo sem energia (FINISH HIM) ^ ------------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------------------------




    } // public void onScannedRobot(ScannedRobotEvent e)


	// x x x
    // Métodos para o GuessFactor 1 v 1 --------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------------------------------

	public static double getGunAngle(int keyLength, double distance, double bulletPower) { // Retornar a previsão de ângulo que será utilizada para atirar
        int indexSize = 0;
        int[] index = new int[MAX_MATCHES];
        int tempIndex = 0;
        int[] bins = new int[GUN_BINS]; 
        do{
            do{
               if( tempIndex < 0 )
                  keyLength= (keyLength*3)/4; // Reduz progressivamente se necessário para garantir uma correspondência na string dinâmica
            
               tempIndex = data.indexOf(
                  data.substring(0, keyLength),tempIndex + 2); // Procura por padrões que começam no início de data e se repetem
            
            } while((tempIndex < 0  || Arrays.binarySearch(index,tempIndex) >= 0) && keyLength > 0);	
            if(keyLength == 0)
               break;
            int iterateIndex = index[0] = tempIndex;
            Arrays.sort(index);
            
            double tempDist = distance;
            double absBearing = 0;
            double db = 0;
            char comboChar;
            do {  
				// Ajusta as variáveis baseando-se nos dados de velocidade armazenados em data
               absBearing += (byte)((comboChar = data.charAt(iterateIndex--))>>8)/tempDist;
               tempDist += (byte)(comboChar&0XFF);    
            } while (comboChar != ROUND_BREAK && (db+=Rules.getBulletSpeed(bulletPower)) < tempDist && iterateIndex > 0);
         	
            if(comboChar != ROUND_BREAK && iterateIndex > 0)
               bins[(int)(PaarthurnaxWings.absNormalize(absBearing)*((GUN_BINS - 1)/(2*Math.PI)))]+= keyLength;
               
                     
        } while(++indexSize < MAX_MATCHES);
         
        keyLength = GUN_BINS - 1;
        tempIndex = 0;
        do {
            if(bins[keyLength] > bins[tempIndex])
               tempIndex = keyLength; // Indica o ângulo mais promissor para atirar
        } while(keyLength-- > 0);
            
        return tempIndex*(2*Math.PI/(GUN_BINS - 1));
    } 

	public double getBullePower1v1(double enemyDistance, double enemyEnergy) { // Cálculo do poder de disparo
        double bulletPower;
        if(enemyDistance < 150){ 
            return bulletPower = 3;
        } else {
			// Retorna o valor minimo entre 2, a energia do Paarthurnax dividida por 16 ou a energia do inimigo dividida por 2
            return bulletPower = Math.min(2, Math.min(getEnergy()/16, enemyEnergy/2)); 
        }
    }

    // ^ Métodos para o GuessFactor 1 v 1 ^ ----------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------------------------------




	// x x x
    // Métodos para Esquiva 1 v 1 --------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------------------------------

	static class OndaInimiga { // Classe das ondas geradas pelas balas dos inimigos
        Point2D.Double localDisparo;
        double velDisparo, angDireto, distPercorrida;
        int direcaoOnda;
		double[] bins;
    }

	public OndaInimiga getPossEsquiva() { // Verifica se ainda existem ondas esquiváveis 
        double menorDistancia = 50000; 
        OndaInimiga esquivar = null;

        for (int x = 0; x < ondasIni.size(); x++){
            OndaInimiga oi = (OndaInimiga)ondasIni.get(x);
            double distance = mLocal.distance(oi.localDisparo) - oi.distPercorrida;

            if (distance > oi.velDisparo && distance < menorDistancia) {
                esquivar = oi;
                menorDistancia = distance;
            }
        }
        return esquivar;
    }

	public static void addWave(double deltaEnergy) { // Adiciona as ondas em ondasIni
        if (ondaPassada.size() > 2 && deltaEnergy <= 3 && deltaEnergy > 0.009){
        	OndaInimiga oi = (OndaInimiga)ondaPassada.get(2);
            oi.velDisparo = Rules.getBulletSpeed(deltaEnergy);
            oi.localDisparo = iLocal;
            ondasIni.add(oi);
        }
    }

	public static void atualizaOndas() { // Atualização de ondas, verificando a distância dela em relação ao Paarthurnax
        double minDist = Double.NEGATIVE_INFINITY;
        surfWave = null;
        Iterator it = ondasIni.iterator();
        while(it.hasNext()) {
            OndaInimiga oi;
            double dist;
            if ((dist = ((oi = (OndaInimiga)it.next()).distPercorrida += oi.velDisparo )- mLocal.distance(oi.localDisparo)) > 50) {
               it.remove();
               continue;
            }
            if(dist > minDist && dist < -18){
               surfWave = oi;
               minDist = dist;   
            }
        }
    }

	public static int getFatorIndex(OndaInimiga oi, Point2D.Double localAlvo) {
		return (int)Math.round(posNegLimit((PaarthurnaxWings.normalize(rumoAbs(oi.localDisparo, localAlvo)  - oi.angDireto) * oi.direcaoOnda /  
			Math.asin(8.0/oi.velDisparo)), 1) * (CENTER_BIN) + (CENTER_BIN));
    }

	public static void logDanoRecebido(OndaInimiga oi, Point2D.Double localAlvo) { // Ao sofrer dano atualiza bins da onda e a direção da possível esquiva 
        int index = getFatorIndex(oi, localAlvo);
		int x = 0;
		do{
        	double increment;
            noSegSurfStats[x] = 0.009*noSegSurfStats[x] + 0.001/(increment = (index - x)*(index - x)/5 + 1);
            oi.bins[x] = 0.3*oi.bins[x] + 0.7/increment;
         }while(++x < BINS);
    }

	public void onBulletHitBullet(BulletHitBulletEvent e) { // Atualização após colisão de tiro
        logEnemyBullet(e.getHitBullet());
    }

	public void onHitByBullet(HitByBulletEvent e) { // Atualizações ao receber dano
		logEnemyBullet(e.getBullet());
        eneInimigo += 3*e.getBullet().getPower();
		PaarthurnaxPrey enemy = PaarthurnaxWings.getEnemy(e.getName());
		enemy.logHit(e.getTime());
		enemy.energy += e.getPower()*3;
    }

	
	public void onBulletHit(BulletHitEvent e) { // Atualizações ao dar dano
		double power = e.getBullet().getPower();
		double tempDamage = Math.max(4*power, 6*power-2);
		PaarthurnaxPrey tempEnemy = PaarthurnaxWings.getEnemy(e.getName());
		tempEnemy.energy -= tempDamage;
		eneInimigo -= Rules.getBulletDamage(e.getBullet().getPower());
	}

	public static void logEnemyBullet(Bullet b) {
    	// Procura nas ondas inimigas alguma que podia ter acertado
        Point2D.Double hitLocation =  new Point2D.Double(b.getX(), b.getY()); 
        Iterator it = ondasIni.iterator();
        while (it.hasNext()) {
        	OndaInimiga oi = (OndaInimiga)it.next();
            if (Math.abs(oi.distPercorrida - hitLocation.distance(oi.localDisparo)) <= 40
                     && Math.abs(Rules.getBulletSpeed(b.getPower()) - oi.velDisparo) < 0.1){
            	logDanoRecebido(oi,hitLocation); // Declara dano recebido passando para o log de dano
            	it.remove(); // Remove a onda
            }
         }
      }


	public double prevendoFuturo(int direcao) {
    	Point2D.Double posicaoPrevista = mLocal;
    	double velocidadePrevista = getVelocity();
    	double rumoPrevisto = getHeadingRadians();
    	double moverAng, moverDirecao;

        int contador = 0; 

    	do{
    		moverAng = paredeSuavizada(posicaoPrevista, rumoAbs(iLocal, posicaoPrevista) + (direcao * (offsetEsquiva(posicaoPrevista.distance(iLocal)))), direcao)- rumoPrevisto;
    		moverDirecao = 1;

    		if(Math.cos(moverAng) < 0){
    			moverAng += Math.PI;
    			moverDirecao = -1;
    		}

    		rumoPrevisto = PaarthurnaxWings.normalize(rumoPrevisto + + posNegLimit(PaarthurnaxWings.normalize(moverAng), Rules.getTurnRateRadians(Math.abs(velocidadePrevista))));
			velocidadePrevista = posNegLimit(velocidadePrevista += (velocidadePrevista * moverDirecao < 0 ? 2*moverDirecao : moverDirecao), 8);

    		posicaoPrevista = project(posicaoPrevista, rumoPrevisto, velocidadePrevista);

    	}while(surfWave != null && posicaoPrevista.distance(surfWave.localDisparo) - 18 > surfWave.distPercorrida  + ((++contador) * surfWave.velDisparo));

		velocidadePrevista = 1;
		if(surfWave != null){
            velocidadePrevista = surfWave.bins[direcao = getFatorIndex(surfWave, posicaoPrevista)] + noSegSurfStats[direcao]; 
        }

    	return velocidadePrevista / posicaoPrevista.distanceSq(iLocal); // posicaoPrevista.distanceSq(iLocal) retorna a raiz da distância entre a posição prevista e o local do inimigo
    }

	public static double offsetEsquiva(double distance) {
    	return (Math.PI/2 - 0.4) + (0.4/475)*distance;
    }

	public static double posNegLimit(double value, double max) {
        return Math.max(-max, Math.min(value, max));
    }
	
	// ^ Métodos para Esquiva 1 v 1 ^ ----------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------------------------------




	// x x x
    // Métodos Utilitários ---------------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------------------------------

	// Método para contornar a parede do mapa sem colidir com ela
	public static double paredeSuavizada(Point2D.Double rLocal, double ang, int ori) {
		do{
			ang += ori * 0.05;
		} while (!limiteMapa.contains(project(rLocal, ang, 170)));
        return ang;
    }

	public static Point2D.Double project(Point2D.Double sourceLocation, double ang, double length) {
        return new Point2D.Double(sourceLocation.x + Math.sin(ang) * length,
            sourceLocation.y + Math.cos(ang) * length);
    }

    public static double rumoAbs(Point2D.Double source, Point2D.Double target) {
        return Math.atan2(target.x - source.x, target.y - source.y);
    } 

    public static double limite(double min, double valor, double max) {
        return Math.max(min, Math.min(valor, max));
    }

    public static double velDisparo(double poder) {
        return (20D - (3D*poder));
    }

    public static double angDesvioMax(double velocidade) {
        return Math.asin(8.0/velocidade);
    }

	// Método que verifica a direção adequada conforme o ângulo ao qual quer virar (Se movendo para frente ou para trás)
	public static void virarFrenteTras(AdvancedRobot boneco, double pAng) {
        double ang = PaarthurnaxWings.normalize(pAng - boneco.getHeadingRadians());
        if (Math.abs(ang) > (Math.PI/2)) {
            if (ang < 0) {
                boneco.setTurnRightRadians(Math.PI + ang);
            } else {
                boneco.setTurnLeftRadians(Math.PI - ang);
            }
            boneco.setBack(100);
        } else {
            if (ang < 0) {
                boneco.setTurnLeftRadians(-1*ang);
           } else {
                boneco.setTurnRightRadians(ang);
           }
            boneco.setAhead(100);
        }
    } 

    private double angRelativoInimigo(double heading) {
		return PaarthurnaxWings.normalize(Math.atan2(inimigoAlvo.x - getX(), inimigoAlvo.y
				- getY())
				- heading);
	} // Retorna o ângulo normalizado relativo do inimigo

    private static int sign(double v) {
		return v > 0 ? 1 : -1;
	} // Apenas uma condição para verificar direção
	
	// ^ Métodos Utilitários ^ -----------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------------------------------




	// x x x
    // Métodos de Eventos ----------------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------------------------------

	public void onDeath(DeathEvent e) {
		PaarthurnaxWings.reiniciaRound();
	} // Limpa os HashMap enemies, limpa os inimigos

	public void onWin(WinEvent e) {
		PaarthurnaxWings.reiniciaRound();
		setAhead(15);
		setTurnGunLeftRadians(Double.POSITIVE_INFINITY);
		turnRadarLeftRadians(Double.POSITIVE_INFINITY);
	} // Dancinha de vitória

	public void onRobotDeath(RobotDeathEvent e) {
		PaarthurnaxWings.robotDeath(e.getName());
	} // Quando um inimigo morre, remove do HashMap enemies, ou seja, remove dos possíveis inimigos

	// ^ Métodos de Eventos ^ ------------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------------------------------




} // public class Paarthurnax extends AdvancedRobot