package low.core.utility;

import java.util.*;
import low.core.utility.*;
import robocode.*;

// Classe responsável pelo controle do Radar 
public class PaarthurnaxEyes {
    private static double direcaoRadar = 1; // 
	
	// Ativação do Radar
    public static void ativaRadar(AdvancedRobot boneco, PaarthurnaxPrey alvo){ 
		if (alvo != null && (boneco.getOthers() == 1 || boneco.getGunHeat()/boneco.getGunCoolingRate() <= 5) && (boneco.getTime()-alvo.lastScanTime < 12 || boneco.getGunHeat() > 0) ||
		alvo != null && alvo.energy < 10.0){		// Controle do Radar: Primeira condição de trava -> Tem que ter alvo, tem que existir só 1 alvo ou arma pronta para disparar e 
			travaRadar(boneco, alvo);				// última troca de alvo em menos de 12 turnos ou arma em estado de aquecimento.
		} else {									// Segunda condição de trava -> Tem que ter alvo e ele tem que estar com energia menor que 10 (trava para finalizar).
			giraRadar(boneco);						// Caso nenhuma das condições de trava forem atendidas o radar continua girando.
		}    
	}
	
	// Radar girando 
    public static void giraRadar(AdvancedRobot boneco){
		boneco.setTurnRadarRightRadians(getRadarDirection()*100);
	}

	// Radar Travado
    public static void travaRadar(AdvancedRobot boneco, PaarthurnaxPrey alvo){
		double angRadar = PaarthurnaxWings.normalize(PaarthurnaxWings.angle(alvo, PaarthurnaxWings.getMyLocation())-boneco.getRadarHeadingRadians());
		if (angRadar > 0){
			angRadar += Math.PI/8;
			setRadarDirection(1);
		} else {
			angRadar -= Math.PI/8;
			setRadarDirection(-1);
		}
		boneco.setTurnRadarRightRadians(angRadar);
	}

	// Retorna a direção do radar
    public static double getRadarDirection(){
		return direcaoRadar;
	}

	// Define a direção do radar
    public static void setRadarDirection(double direcao){
		direcaoRadar = direcao;
	}
}