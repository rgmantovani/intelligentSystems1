package low.core.utility;

import java.util.*;
import java.awt.geom.*;
import robocode.*;
import low.core.utility.*;
import low.core.combat.*;

// Classe voltada ao gerenciamento dos inimigos
public class PaarthurnaxPrey extends Point2D.Double{

    public double distance, bearing, heading, velocity, velocityChange, energy, lastBulletPower, lastMoveDirection;
	public long lastHitTime, lastScanTime, lastScanDelay, lastNewMovementTime, lastShotTime, lastShotTimeInterval, lastShotFactor;
	public String name;
	public Point2D lastMyLocation;
	public PaarthurnaxPrey currentTarget;
	public WordsOfPower lastWave, lastRemovedWave;
	public ArrayList bullets;

    public PaarthurnaxPrey() {
		bullets = new ArrayList();
		lastMoveDirection = 1;
		lastBulletPower = 3;
		lastShotTime = 0;
		lastShotTimeInterval = 0;
		energy = 100;
	}

    public void update(AdvancedRobot robot, ScannedRobotEvent e){
		name = e.getName();
		double energydiff = energy-e.getEnergy();
		energy = e.getEnergy();
		if (energydiff > .0999 && energydiff <= 3){
			lastShotTime = e.getTime() - lastShotTimeInterval;
			lastBulletPower = energydiff;
		} else {
			lastShotTimeInterval = e.getTime();
		}
		lastShotFactor = lastShotTime - lastShotTimeInterval; // Fator de último tiro para saber o tempo em relação ao último disparo por número de turnos
		// Atualiza status atuais
		setLocation(PaarthurnaxWings.projectPoint(PaarthurnaxWings.getMyLocation(), robot.getHeadingRadians() + e.getBearingRadians(), e.getDistance()));
		lastScanDelay = e.getTime() - lastScanTime;
		lastScanTime = e.getTime();
		velocityChange = e.getVelocity()-velocity;
		if (Math.abs(velocityChange) >= .5)
			lastNewMovementTime = e.getTime();
		velocity = e.getVelocity();
		heading = e.getHeadingRadians();
		bearing = e.getBearingRadians();
		distance = e.getDistance();
		if (velocity != 0){
			lastMoveDirection = (velocity < 0) ? -1 : 1;
		}
	}

    public void update(AdvancedRobot robot){
		name = robot.getName();
		double energydiff = energy-robot.getEnergy();
		energy = robot.getEnergy();
		if (energydiff > .0999 && energydiff <= 3){
			lastShotTime = robot.getTime()-1;
			lastBulletPower = energydiff;
		}
		// Atualiza status atuais
		setLocation(robot.getX(), robot.getY());
		lastScanDelay = robot.getTime() - lastScanTime;
		lastScanTime = robot.getTime();
		velocityChange = robot.getVelocity()-velocity;
		if (Math.abs(velocityChange) >= .5)
			lastNewMovementTime = robot.getTime();
		velocity = robot.getVelocity();
		heading = robot.getHeadingRadians();
		if (velocity != 0){
			lastMoveDirection = (velocity < 0) ? -1 : 1;
		}
	}

	public int[] getSegmentIndexes(){
		boolean melee = PaarthurnaxWings.getRobot().getOthers() != 1;
		int[] indexes = new int[(melee ? PaarthurnaxWings.meleeSegmentSizes.length : PaarthurnaxWings.segmentSizes.length)+1];
		indexes[0] = PaarthurnaxWings.getRobot().getOthers() == 1 ? 0 : 1;
		
		//Segmentação da parede
		indexes[1] = PaarthurnaxWings.inField(PaarthurnaxWings.projectPoint(this, heading, lastMoveDirection*80)) ? 0 : 1;
		
		//Segmentação da aceleração:
		// 0 significa que sinal da velocidade == - sinal da troca de velocidade (desacelerando)
		// 1 significa que a alteração da velocidade é quase nula
		// 2 significa que sinal de velocidade e troca de velocidade são quase iguais
		indexes[2] = (int)(lastMoveDirection*Math.min(1, Math.max(-1, velocityChange)))+1;

		// Caso a velocidade seja 8 e o último scan tenha sido feito a um bom tempo é provável que estejam em velocidade constante
		if (Math.abs(velocity) > 7.9 && lastScanDelay > 3)
			indexes[2] = 1;
		
		//Segmentação da velocidade lateral
		double latd = Math.cos(heading-PaarthurnaxWings.angle(this, PaarthurnaxWings.getMyLocation()));
		indexes[3] = (int)(latd*lastMoveDirection*1.4+1.4);
		double bft = distance(PaarthurnaxWings.getMyLocation())/PaarthurnaxWings.getBulletVelocity(PaarthurnaxWings.getPower(this)); // Tempo = espaço/velocidade
		if (melee){	// Segmentos específicos para battle royale
			int best = 0;
			double angle = PaarthurnaxWings.angle(this, PaarthurnaxWings.getMyLocation());
			for (int i=0; i<PaarthurnaxWings.meleeSegmentSizes[3]; i++)
				if (PaarthurnaxLegs.rawAntigravityAtPoint(PaarthurnaxWings.projectPoint(this, angle+i*Math.PI*2/PaarthurnaxWings.meleeSegmentSizes[3]*getLateralDirection(), 100), this) < PaarthurnaxLegs.rawAntigravityAtPoint(PaarthurnaxWings.projectPoint(this, angle+best*Math.PI*2/PaarthurnaxWings.meleeSegmentSizes[3]*getLateralDirection(), 100), this))
					best = i;
			indexes[4] = best;
		} else { // Segmentos especificos de 1 v 1 (Att: não utilizando)
			//Segmentação de velocidade
			indexes[4] = (int)Math.abs(Math.sin(heading-PaarthurnaxWings.angle(this, PaarthurnaxWings.getMyLocation()))*velocity/3);
			//Segmentação de tempo
			indexes[5] = (int)Math.min(3, (lastScanTime-lastNewMovementTime)*3/bft);
		}
		
		// Segmentação do bft (bullet fly time)
		indexes[indexes.length-1] = (int)Math.min(9, bft/10);
		return indexes;
	}

	public int[] getSelfSegmentIndexes(PaarthurnaxPrey fromEnemy){
		int[] indexes = new int[PaarthurnaxWings.selfSegmentSizes.length+1];
		// Battle Royale:
		indexes[0] = Math.min(PaarthurnaxWings.getRobot().getOthers()-1, 1);
		
		// Parede:
		indexes[1] = PaarthurnaxWings.inField(PaarthurnaxWings.projectPoint(this, heading, lastMoveDirection*80)) ? 0 : 1;
		
		// Aceleração:
		indexes[2] = (int)(lastMoveDirection*Math.min(1, Math.max(-1, velocityChange)))+1;
		
		// Velocidade lateral:
		double latv = Math.sin(heading-PaarthurnaxWings.angle(this, fromEnemy));
		indexes[3] = (int)Math.abs(latv/3);

		// Tempo:
		double bft = distance(fromEnemy)/PaarthurnaxWings.getBulletVelocity(fromEnemy.lastBulletPower); // Tempo = espaço/velocidade
		indexes[4] = (int)Math.min(3, (lastScanTime-lastNewMovementTime)*3/bft);
		
		// Bft (bullet fly time):
		indexes[5] = (int)Math.min(9, bft/10);
		return indexes;
	}

	public void updateWaves(int[] segment, long time, int[] indexes){
		for (int i=0; i<bullets.size(); i++){
			WordsOfPower wave = (WordsOfPower)bullets.get(i);
			if (wave.updateEnemy(this, time)){
				if (wave.weight > 1)
					lastRemovedWave = wave;
				bullets.remove(i);
				i--;
			}
		}
		bullets.add(lastWave = new WordsOfPower(this, time, segment, indexes));
	}

	public void updateWaves(int[] segment, long time, PaarthurnaxPrey from, int[] indexes){
		for (int i=0; i<bullets.size(); i++){
			WordsOfPower wave = (WordsOfPower)bullets.get(i);
			if (wave.updateEnemy(this, time)){
				if (wave.weight > 0)
					lastRemovedWave = wave;
				bullets.remove(i);
				i--;
			}
		}
		bullets.add(lastWave = new WordsOfPower(PaarthurnaxWings.getRobot(), from, segment, time, getLateralDirection(from), from.lastBulletPower, indexes));
	}

	public double getLateralDirection(PaarthurnaxPrey from){
		double latv = Math.sin(heading-PaarthurnaxWings.angle(this, from))*lastMoveDirection;
		if (latv < 0)
			return -1;
		else
			return 1;
	} // Retorna a direção lateral (1 frente, -1 costas)

	public double getLateralDirection(){
		double latv = Math.sin(heading-PaarthurnaxWings.angle(this, PaarthurnaxWings.getMyLocation()))*lastMoveDirection;
		if (latv < 0)
			return -1;
		else
			return 1;
	} // Retorna a direção lateral (1 frente, -1 costas)

	public void logHit(long time){
		lastHitTime = time;
	}
}